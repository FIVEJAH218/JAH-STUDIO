(() => {
  const $ = id => document.getElementById(id);
  const { jsPDF } = window.jspdf;
  const KEY = 'jahStudioProjectV14';
  const OLD_KEY = 'jahStudioProjectV13';
  const templates = {a3p:[297,420],a3l:[420,297],a4p:[210,297],b4p:[257,364],b5p:[182,257],leftchest:[100,100],sleeve:[90,300],senjafuda:[45,135]};
  let pageW=297,pageH=420,seq=1,guideObjs=[],saveTimer=null;
  let history=[],historyIndex=-1,historyBusy=false;
  let cropTarget=null,cropRect={x:0,y:0,w:0,h:0},cropDrag=null;
  const canvas=new fabric.Canvas('editor',{preserveObjectStacking:true,selection:true,backgroundColor:'#fff',allowTouchScrolling:false});

  const status=t=>$('status').textContent=t;
  const userObjects=()=>canvas.getObjects().filter(o=>!o.excludeFromExport);
  const active=()=>canvas.getActiveObject();
  const screenZoom=()=>Math.min(Math.min(innerWidth-52,560)/pageW,(innerWidth<760?560:680)/pageH,3.2);
  const isRaster=o=>o && o.type==='image' && o._element;

  function resizeCanvas(){
    const z=screenZoom();
    canvas.setWidth(Math.round(pageW*z));canvas.setHeight(Math.round(pageH*z));canvas.setZoom(z);
    $('canvasWrap').style.width=canvas.getWidth()+'px';$('canvasWrap').style.height=canvas.getHeight()+'px';
    $('sizeLabel').textContent=`${pageW} × ${pageH} mm`;drawGuides();canvas.requestRenderAll();
  }
  function drawGuides(){
    guideObjs.forEach(o=>canvas.remove(o));guideObjs=[];
    if($('grid').checked){
      for(let x=10;x<pageW;x+=10)guideObjs.push(new fabric.Line([x,0,x,pageH],{stroke:'#ddd',strokeWidth:.25,selectable:false,evented:false,excludeFromExport:true}));
      for(let y=10;y<pageH;y+=10)guideObjs.push(new fabric.Line([0,y,pageW,y],{stroke:'#ddd',strokeWidth:.25,selectable:false,evented:false,excludeFromExport:true}));
    }
    if($('guides').checked){
      const c={stroke:'#00a4c7',strokeWidth:.35,selectable:false,evented:false,excludeFromExport:true};
      guideObjs.push(new fabric.Line([pageW/2,0,pageW/2,pageH],c),new fabric.Line([0,pageH/2,pageW,pageH/2],c));
      const m=Math.min(10,pageW*.06,pageH*.06);
      guideObjs.push(new fabric.Rect({left:m,top:m,width:pageW-m*2,height:pageH-m*2,fill:'transparent',stroke:'#e36b2c',strokeWidth:.35,strokeDashArray:[3,2],selectable:false,evented:false,excludeFromExport:true}));
    }
    guideObjs.forEach(g=>canvas.add(g));guideObjs.forEach(g=>canvas.sendToBack(g));
  }
  function applyTemplate(v,record=true){
    if(v!=='custom'){[pageW,pageH]=templates[v];$('docW').value=pageW;$('docH').value=pageH;}
    else {pageW=Math.max(10,+$('docW').value||297);pageH=Math.max(10,+$('docH').value||420);}
    resizeCanvas();if(record)recordHistory();scheduleSave();status(`テンプレートを ${pageW}×${pageH}mm に変更しました。`);
  }

  function tag(o,name){o._jahId='jah_'+seq++;o._jahName=name||'素材';o.set({transparentCorners:false,cornerColor:'#111',cornerStyle:'circle',borderColor:'#111',padding:2});return o;}
  function addRaster(url,name){fabric.Image.fromURL(url,img=>{tag(img,name);const s=Math.min((pageW*.65)/img.width,(pageH*.65)/img.height,1);img.set({left:pageW/2,top:pageH/2,originX:'center',originY:'center',scaleX:s,scaleY:s});canvas.add(img).setActiveObject(img);afterChange(`${name} を追加しました。`);});}
  function addSvg(text,name){fabric.loadSVGFromString(text,(objects,options)=>{const obj=fabric.util.groupSVGElements(objects,options);tag(obj,name);const s=Math.min((pageW*.65)/obj.width,(pageH*.65)/obj.height,1);obj.set({left:pageW/2,top:pageH/2,originX:'center',originY:'center',scaleX:s,scaleY:s});canvas.add(obj).setActiveObject(obj);afterChange(`${name} を追加しました。`);});}
  function afterChange(msg){refreshLayers();updateInfo();recordHistory();scheduleSave();if(msg)status(msg);}

  $('template').onchange=e=>applyTemplate(e.target.value);
  $('docW').onchange=()=>{$('template').value='custom';applyTemplate('custom');};
  $('docH').onchange=()=>{$('template').value='custom';applyTemplate('custom');};
  ['guides','grid'].forEach(id=>$(id).onchange=()=>{drawGuides();scheduleSave();});
  $('snap').onchange=scheduleSave;
  $('addImage').onclick=()=>$('imageInput').click();
  $('imageInput').onchange=e=>{[...e.target.files].forEach(file=>{const r=new FileReader();const svg=file.type==='image/svg+xml'||file.name.toLowerCase().endsWith('.svg');r.onload=ev=>svg?addSvg(ev.target.result,file.name):addRaster(ev.target.result,file.name);svg?r.readAsText(file):r.readAsDataURL(file);});e.target.value='';};
  $('addText').onclick=()=>$('textDialog').showModal();$('cancelText').onclick=()=>$('textDialog').close();
  $('confirmText').onclick=()=>{const t=$('textValue').value||'TEXT';const o=new fabric.Textbox(t,{left:pageW/2,top:pageH/2,originX:'center',originY:'center',width:pageW*.7,fontSize:18,fontFamily:$('fontFamily').value,fill:'#111',textAlign:'center'});tag(o,'文字: '+t);canvas.add(o).setActiveObject(o);$('textDialog').close();afterChange();};
  $('remove').onclick=()=>{const o=active();if(o){canvas.remove(o);afterChange();}};
  $('duplicate').onclick=()=>{const o=active();if(!o)return;o.clone(c=>{tag(c,(o._jahName||'素材')+' コピー');c.set({left:o.left+8,top:o.top+8});canvas.add(c).setActiveObject(c);afterChange();});};
  $('centerX').onclick=()=>{const o=active();if(o){o.set({left:pageW/2,originX:'center'});canvas.requestRenderAll();afterChange();}};
  $('centerY').onclick=()=>{const o=active();if(o){o.set({top:pageH/2,originY:'center'});canvas.requestRenderAll();afterChange();}};
  $('fit').onclick=()=>{const o=active();if(!o)return;const b=o.getBoundingRect(true,true),s=Math.min((pageW*.9)/b.width,(pageH*.9)/b.height);o.scaleX*=s;o.scaleY*=s;o.set({left:pageW/2,top:pageH/2,originX:'center',originY:'center'});canvas.requestRenderAll();afterChange();};
  $('front').onclick=()=>{const o=active();if(o){canvas.bringToFront(o);guideObjs.forEach(g=>canvas.bringToFront(g));afterChange();}};
  $('back').onclick=()=>{const o=active();if(o){canvas.sendToBack(o);guideObjs.forEach(g=>canvas.sendToBack(g));afterChange();}};
  $('opacity').oninput=()=>{const o=active();$('opacityValue').textContent=$('opacity').value+'%';if(o){o.set('opacity',+$('opacity').value/100);canvas.requestRenderAll();scheduleSave();}};
  $('applyObject').onclick=()=>{const o=active();if(!o)return;const cw=o.getScaledWidth(),ch=o.getScaledHeight(),tw=Math.max(.1,+$('objW').value||cw),th=Math.max(.1,+$('objH').value||ch);if($('lockRatio').value==='on'){const f=tw/cw;o.scaleX*=f;o.scaleY*=f;}else{o.scaleX*=tw/cw;o.scaleY*=th/ch;}o.set({left:+$('objX').value||0,top:+$('objY').value||0,originX:'left',originY:'top',angle:+$('objAngle').value||0});canvas.requestRenderAll();afterChange();};

  function sourceCanvas(o){
    const el=o._element; const w=el.naturalWidth||el.width, h=el.naturalHeight||el.height;
    const c=document.createElement('canvas');c.width=w;c.height=h;const ctx=c.getContext('2d',{willReadFrequently:true});ctx.drawImage(el,0,0,w,h);return c;
  }
  function replaceRaster(o,c,nameSuffix,position){
    const oldIndex=canvas.getObjects().indexOf(o);
    const props={left:o.left,top:o.top,originX:o.originX,originY:o.originY,scaleX:o.scaleX,scaleY:o.scaleY,angle:o.angle,flipX:o.flipX,flipY:o.flipY,opacity:o.opacity,skewX:o.skewX,skewY:o.skewY};
    if(position){props.left=position.x;props.top=position.y;props.originX='center';props.originY='center';}
    const img=new fabric.Image(c,props);tag(img,(o._jahName||'画像')+nameSuffix);
    canvas.remove(o);canvas.insertAt(img,Math.max(0,oldIndex),false);canvas.setActiveObject(img);canvas.requestRenderAll();afterChange(`${nameSuffix.replace(/^ /,'')}を適用しました。`);
  }
  $('whiteThreshold').oninput=()=>$('whiteThresholdValue').textContent=$('whiteThreshold').value;
  $('removeWhite').onclick=()=>{
    const o=active();if(!isRaster(o)){status('白抜きは画像（PNG/JPG）を選択して使います。');return;}
    try{const c=sourceCanvas(o),ctx=c.getContext('2d',{willReadFrequently:true}),d=ctx.getImageData(0,0,c.width,c.height),t=+$('whiteThreshold').value;
      for(let i=0;i<d.data.length;i+=4){const r=d.data[i],g=d.data[i+1],b=d.data[i+2];if(r>=t&&g>=t&&b>=t)d.data[i+3]=0;}
      ctx.putImageData(d,0,0);replaceRaster(o,c,' 白抜き');
    }catch(e){status('白抜きに失敗しました。別の画像で試してください。');}
  };
  $('makeBlack').onclick=()=>{
    const o=active();if(!isRaster(o)){status('黒ベタ化は画像（PNG/JPG）を選択して使います。');return;}
    try{const c=sourceCanvas(o),ctx=c.getContext('2d',{willReadFrequently:true}),d=ctx.getImageData(0,0,c.width,c.height);
      for(let i=0;i<d.data.length;i+=4){if(d.data[i+3]>0){d.data[i]=0;d.data[i+1]=0;d.data[i+2]=0;}}
      ctx.putImageData(d,0,0);replaceRaster(o,c,' 黒ベタ');
    }catch(e){status('黒ベタ化に失敗しました。別の画像で試してください。');}
  };

  function openCrop(){
    const o=active();if(!isRaster(o)){status('トリミングは画像（PNG/JPG）を選択して使います。');return;}
    cropTarget=o;const src=sourceCanvas(o);$('cropPreview').src=src.toDataURL('image/png');$('cropDialog').showModal();
    $('cropPreview').onload=()=>requestAnimationFrame(()=>{const r=$('cropPreview').getBoundingClientRect(),sr=$('cropStage').getBoundingClientRect();cropRect={x:r.left-sr.left+r.width*.08,y:r.top-sr.top+r.height*.08,w:r.width*.84,h:r.height*.84};renderCropBox();});
  }
  function renderCropBox(){const b=$('cropBox');b.style.left=cropRect.x+'px';b.style.top=cropRect.y+'px';b.style.width=cropRect.w+'px';b.style.height=cropRect.h+'px';}
  function cropBounds(){const ir=$('cropPreview').getBoundingClientRect(),sr=$('cropStage').getBoundingClientRect();return{x:ir.left-sr.left,y:ir.top-sr.top,w:ir.width,h:ir.height};}
  $('cropImage').onclick=openCrop;$('cancelCrop').onclick=()=>{$('cropDialog').close();cropTarget=null;};
  $('cropBox').addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();const h=e.target.dataset.handle||'move';cropDrag={mode:h,startX:e.clientX,startY:e.clientY,start:{...cropRect}};$('cropBox').setPointerCapture(e.pointerId);});
  $('cropBox').addEventListener('pointermove',e=>{if(!cropDrag)return;const dx=e.clientX-cropDrag.startX,dy=e.clientY-cropDrag.startY,b=cropBounds(),min=28,s=cropDrag.start;let r={...s};
    if(cropDrag.mode==='move'){r.x=Math.max(b.x,Math.min(b.x+b.w-s.w,s.x+dx));r.y=Math.max(b.y,Math.min(b.y+b.h-s.h,s.y+dy));}
    else {if(cropDrag.mode.includes('w')){r.x=Math.max(b.x,Math.min(s.x+s.w-min,s.x+dx));r.w=s.w+(s.x-r.x);}if(cropDrag.mode.includes('e'))r.w=Math.max(min,Math.min(b.x+b.w-s.x,s.w+dx));if(cropDrag.mode.includes('n')){r.y=Math.max(b.y,Math.min(s.y+s.h-min,s.y+dy));r.h=s.h+(s.y-r.y);}if(cropDrag.mode.includes('s'))r.h=Math.max(min,Math.min(b.y+b.h-s.y,s.h+dy));}
    cropRect=r;renderCropBox();
  });
  ['pointerup','pointercancel'].forEach(ev=>$('cropBox').addEventListener(ev,()=>cropDrag=null));
  $('confirmCrop').onclick=()=>{
    const o=cropTarget;if(!isRaster(o))return;const b=cropBounds(),el=o._element,iw=el.naturalWidth||el.width,ih=el.naturalHeight||el.height;
    const sx=Math.max(0,Math.round((cropRect.x-b.x)/b.w*iw)),sy=Math.max(0,Math.round((cropRect.y-b.y)/b.h*ih));
    const sw=Math.max(1,Math.min(iw-sx,Math.round(cropRect.w/b.w*iw))),sh=Math.max(1,Math.min(ih-sy,Math.round(cropRect.h/b.h*ih)));
    const out=document.createElement('canvas');out.width=sw;out.height=sh;out.getContext('2d').drawImage(el,sx,sy,sw,sh,0,0,sw,sh);
    const local=new fabric.Point(sx+sw/2-iw/2,sy+sh/2-ih/2);const world=fabric.util.transformPoint(local,o.calcTransformMatrix());
    $('cropDialog').close();cropTarget=null;replaceRaster(o,out,' トリミング',world);
  };

  function updateInfo(){const o=active();if(!o){$('selectionInfo').textContent='素材を選択してください';['objW','objH','objX','objY','objAngle'].forEach(id=>$(id).value='');$('opacity').value=100;$('opacityValue').textContent='100%';return;}const w=o.getScaledWidth(),h=o.getScaledHeight();$('selectionInfo').textContent=`${o._jahName||o.type}｜横 ${w.toFixed(1)}mm × 縦 ${h.toFixed(1)}mm｜回転 ${Math.round(o.angle||0)}°`; $('objW').value=w.toFixed(1);$('objH').value=h.toFixed(1);$('objX').value=(o.left||0).toFixed(1);$('objY').value=(o.top||0).toFixed(1);$('objAngle').value=Math.round(o.angle||0);$('opacity').value=Math.round((o.opacity??1)*100);$('opacityValue').textContent=$('opacity').value+'%';}
  function refreshLayers(){const host=$('layers');host.innerHTML='';userObjects().slice().reverse().forEach(o=>{const row=document.createElement('div');row.className='layer'+(active()===o?' active':'');const name=document.createElement('button');name.className='name secondary';name.textContent=o._jahName||o.type;name.onclick=()=>{canvas.setActiveObject(o);canvas.requestRenderAll();refreshLayers();updateInfo();};const up=document.createElement('button');up.className='secondary';up.textContent='↑';up.onclick=()=>{canvas.bringForward(o);guideObjs.forEach(g=>canvas.bringToFront(g));afterChange();};const down=document.createElement('button');down.className='secondary';down.textContent='↓';down.onclick=()=>{canvas.sendBackwards(o);guideObjs.forEach(g=>canvas.bringToFront(g));afterChange();};const lock=document.createElement('button');lock.className='secondary';lock.textContent=o.selectable?'🔓':'🔒';lock.onclick=()=>{const v=o.selectable;o.set({selectable:!v,evented:!v});canvas.discardActiveObject();canvas.requestRenderAll();afterChange();};const del=document.createElement('button');del.className='danger';del.textContent='×';del.onclick=()=>{canvas.remove(o);afterChange();};row.append(name,up,down,lock,del);host.appendChild(row);});}
  function snapObject(o){if(!$('snap').checked)return;if(Math.abs(o.getCenterPoint().x-pageW/2)<4)o.set({left:pageW/2,originX:'center'});if(Math.abs(o.getCenterPoint().y-pageH/2)<4)o.set({top:pageH/2,originY:'center'});}

  function snapshot(){return JSON.stringify({version:'1.4',pageW,pageH,template:$('template').value,guides:$('guides').checked,grid:$('grid').checked,snap:$('snap').checked,json:canvas.toJSON(['_jahId','_jahName','excludeFromExport'])});}
  function recordHistory(){if(historyBusy)return;const s=snapshot();if(history[historyIndex]===s)return;history=history.slice(0,historyIndex+1);history.push(s);if(history.length>30)history.shift();historyIndex=history.length-1;updateHistoryButtons();}
  function updateHistoryButtons(){$('undo').disabled=historyIndex<=0;$('redo').disabled=historyIndex>=history.length-1;}
  function loadState(state){historyBusy=true;const d=JSON.parse(state);pageW=d.pageW;pageH=d.pageH;$('template').value=d.template||'custom';$('docW').value=pageW;$('docH').value=pageH;$('guides').checked=d.guides!==false;$('grid').checked=!!d.grid;$('snap').checked=d.snap!==false;canvas.loadFromJSON(d.json,()=>{resizeCanvas();refreshLayers();updateInfo();historyBusy=false;scheduleSave();updateHistoryButtons();});}
  $('undo').onclick=()=>{if(historyIndex>0){historyIndex--;loadState(history[historyIndex]);}};
  $('redo').onclick=()=>{if(historyIndex<history.length-1){historyIndex++;loadState(history[historyIndex]);}};

  canvas.on('object:moving',e=>snapObject(e.target));
  canvas.on('object:modified',()=>afterChange());
  canvas.on('selection:created',()=>{refreshLayers();updateInfo();});canvas.on('selection:updated',()=>{refreshLayers();updateInfo();});canvas.on('selection:cleared',()=>{refreshLayers();updateInfo();});canvas.on('object:added',refreshLayers);canvas.on('object:removed',refreshLayers);

  function saveNow(){try{localStorage.setItem(KEY,snapshot());status('自動保存しました。');}catch(e){status('保存容量が不足しています。');}}
  function scheduleSave(){clearTimeout(saveTimer);saveTimer=setTimeout(saveNow,350);}
  $('saveProject').onclick=saveNow;$('clearProject').onclick=()=>{localStorage.removeItem(KEY);localStorage.removeItem(OLD_KEY);status('保存データを消去しました。');};
  function restore(){const raw=localStorage.getItem(KEY)||localStorage.getItem(OLD_KEY);if(!raw){applyTemplate('a3p',false);history=[snapshot()];historyIndex=0;updateHistoryButtons();return;}try{historyBusy=true;const d=JSON.parse(raw);pageW=d.pageW||297;pageH=d.pageH||420;$('template').value=d.template||'custom';$('docW').value=pageW;$('docH').value=pageH;$('guides').checked=d.guides!==false;$('grid').checked=!!d.grid;$('snap').checked=d.snap!==false;canvas.loadFromJSON(d.json,()=>{resizeCanvas();refreshLayers();updateInfo();historyBusy=false;history=[snapshot()];historyIndex=0;updateHistoryButtons();scheduleSave();status('前回のプロジェクトを復元しました。');});}catch(e){historyBusy=false;applyTemplate('a3p',false);history=[snapshot()];historyIndex=0;updateHistoryButtons();}}

  function withoutGuides(fn){const old=guideObjs.map(g=>g.visible);guideObjs.forEach(g=>g.visible=false);canvas.discardActiveObject();canvas.requestRenderAll();try{return fn();}finally{guideObjs.forEach((g,i)=>g.visible=old[i]);canvas.requestRenderAll();}}
  function download(url,name){const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();}
  $('exportPng').onclick=()=>{download(withoutGuides(()=>canvas.toDataURL({format:'png',multiplier:4,enableRetinaScaling:true})),'JAH_STUDIO_design.png');status('PNGを書き出しました。');};
  $('exportSvg').onclick=()=>{const svg=withoutGuides(()=>canvas.toSVG({width:pageW+'mm',height:pageH+'mm',viewBox:{x:0,y:0,width:pageW,height:pageH}})),b=new Blob([svg],{type:'image/svg+xml'}),u=URL.createObjectURL(b);download(u,'JAH_STUDIO_design.svg');setTimeout(()=>URL.revokeObjectURL(u),1000);status('SVGを書き出しました。');};
  $('exportPdf').onclick=()=>{const img=withoutGuides(()=>canvas.toDataURL({format:'png',multiplier:4,enableRetinaScaling:true})),pdf=new jsPDF({orientation:pageW>pageH?'landscape':'portrait',unit:'mm',format:[pageW,pageH]});pdf.addImage(img,'PNG',0,0,pageW,pageH,undefined,'FAST');pdf.save('JAH_STUDIO_print.pdf');status('PDFを書き出しました。');};

  addEventListener('resize',resizeCanvas);restore();
})();
