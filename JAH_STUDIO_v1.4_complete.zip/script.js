(() => {
  const $ = id => document.getElementById(id);
  const { jsPDF } = window.jspdf;
  const KEY = 'jahStudioProjectV13'; // v1.3の保存データもそのまま引き継ぐ
  const templates = {a3p:[297,420],a3l:[420,297],a4p:[210,297],b4p:[257,364],b5p:[182,257],leftchest:[100,100],sleeve:[90,300],senjafuda:[45,135]};
  let pageW=297,pageH=420,seq=1,guideObjs=[],saveTimer=null;
  let history=[],historyIndex=-1,historyBusy=false;
  let cropState=null;
  const canvas=new fabric.Canvas('editor',{preserveObjectStacking:true,selection:true,backgroundColor:'#fff',allowTouchScrolling:false});

  const status=t=>$('status').textContent=t;
  const userObjects=()=>canvas.getObjects().filter(o=>!o.excludeFromExport);
  const active=()=>canvas.getActiveObject();
  const screenZoom=()=>Math.min(Math.min(innerWidth-52,560)/pageW,(innerWidth<760?560:680)/pageH,3.2);

  function resizeCanvas(){
    const z=screenZoom();
    canvas.setWidth(Math.round(pageW*z));canvas.setHeight(Math.round(pageH*z));canvas.setZoom(z);
    $('canvasWrap').style.width=canvas.getWidth()+'px';$('canvasWrap').style.height=canvas.getHeight()+'px';
    $('sizeLabel').textContent=`${pageW} × ${pageH} mm`;drawGuides();canvas.requestRenderAll();
  }
  function drawGuides(){
    guideObjs.forEach(o=>canvas.remove(o));guideObjs=[];
    if($('grid').checked){
      for(let x=10;x<pageW;x+=10)guideObjs.push(new fabric.Line([x,0,x,pageH],{stroke:'#ddd',strokeWidth:.25,selectable:false,evented:false,excludeFromExport:true}));
      for(let y=10;y<pageH;y+=10)guideObjs.push(new fabric.Line([0,y,pageW,y],{stroke:'#ddd',strokeWidth:.25,selectable:false,evented:false,excludeFromExport:true}));
    }
    if($('guides').checked){
      const c={stroke:'#00a4c7',strokeWidth:.35,selectable:false,evented:false,excludeFromExport:true};
      guideObjs.push(new fabric.Line([pageW/2,0,pageW/2,pageH],c),new fabric.Line([0,pageH/2,pageW,pageH/2],c));
      const m=Math.min(10,pageW*.06,pageH*.06);
      guideObjs.push(new fabric.Rect({left:m,top:m,width:pageW-m*2,height:pageH-m*2,fill:'transparent',stroke:'#e36b2c',strokeWidth:.35,strokeDashArray:[3,2],selectable:false,evented:false,excludeFromExport:true}));
    }
    guideObjs.forEach(g=>canvas.add(g));guideObjs.forEach(g=>canvas.sendToBack(g));
  }
  function applyTemplate(v,record=true){
    if(v!=='custom'){[pageW,pageH]=templates[v];$('docW').value=pageW;$('docH').value=pageH;}
    else {pageW=Math.max(10,+$('docW').value||297);pageH=Math.max(10,+$('docH').value||420);}
    resizeCanvas();if(record)recordHistory();scheduleSave();status(`テンプレートを ${pageW}×${pageH}mm に変更しました。`);
  }

  function tag(o,name){o._jahId='jah_'+seq++;o._jahName=name||'素材';o.set({transparentCorners:false,cornerColor:'#111',cornerStyle:'circle',borderColor:'#111',padding:2});return o;}
  function addRaster(url,name){fabric.Image.fromURL(url,img=>{tag(img,name);const s=Math.min((pageW*.65)/img.width,(pageH*.65)/img.height,1);img.set({left:pageW/2,top:pageH/2,originX:'center',originY:'center',scaleX:s,scaleY:s});canvas.add(img).setActiveObject(img);afterChange(`${name} を追加しました。`);});}
  function addSvg(text,name){fabric.loadSVGFromString(text,(objects,options)=>{const obj=fabric.util.groupSVGElements(objects,options);tag(obj,name);const s=Math.min((pageW*.65)/obj.width,(pageH*.65)/obj.height,1);obj.set({left:pageW/2,top:pageH/2,originX:'center',originY:'center',scaleX:s,scaleY:s});canvas.add(obj).setActiveObject(obj);afterChange(`${name} を追加しました。`);});}
  function afterChange(msg){refreshLayers();updateInfo();recordHistory();scheduleSave();if(msg)status(msg);}

  $('template').onchange=e=>applyTemplate(e.target.value);
  $('docW').onchange=()=>{$('template').value='custom';applyTemplate('custom');};
  $('docH').onchange=()=>{$('template').value='custom';applyTemplate('custom');};
  ['guides','grid'].forEach(id=>$(id).onchange=()=>{drawGuides();scheduleSave();});
  $('snap').onchange=scheduleSave;
  $('addImage').onclick=()=>$('imageInput').click();
  $('imageInput').onchange=e=>{[...e.target.files].forEach(file=>{const r=new FileReader();const svg=file.type==='image/svg+xml'||file.name.toLowerCase().endsWith('.svg');r.onload=ev=>svg?addSvg(ev.target.result,file.name):addRaster(ev.target.result,file.name);svg?r.readAsText(file):r.readAsDataURL(file);});e.target.value='';};
  $('addText').onclick=()=>$('textDialog').showModal();$('cancelText').onclick=()=>$('textDialog').close();
  $('confirmText').onclick=()=>{const t=$('textValue').value||'TEXT';const o=new fabric.Textbox(t,{left:pageW/2,top:pageH/2,originX:'center',originY:'center',width:pageW*.7,fontSize:18,fontFamily:$('fontFamily').value,fill:'#111',textAlign:'center'});tag(o,'文字: '+t);canvas.add(o).setActiveObject(o);$('textDialog').close();afterChange();};
  $('remove').onclick=()=>{const o=active();if(o){canvas.remove(o);afterChange();}};
  $('duplicate').onclick=()=>{const o=active();if(!o)return;o.clone(c=>{tag(c,(o._jahName||'素材')+' コピー');c.set({left:o.left+8,top:o.top+8});canvas.add(c).setActiveObject(c);afterChange();});};
  $('centerX').onclick=()=>{const o=active();if(o){o.set({left:pageW/2,originX:'center'});canvas.requestRenderAll();afterChange();}};
  $('centerY').onclick=()=>{const o=active();if(o){o.set({top:pageH/2,originY:'center'});canvas.requestRenderAll();afterChange();}};
  $('fit').onclick=()=>{const o=active();if(!o)return;const b=o.getBoundingRect(true,true),s=Math.min((pageW*.9)/b.width,(pageH*.9)/b.height);o.scaleX*=s;o.scaleY*=s;o.set({left:pageW/2,top:pageH/2,originX:'center',originY:'center'});canvas.requestRenderAll();afterChange();};
  $('front').onclick=()=>{const o=active();if(o){canvas.bringToFront(o);guideObjs.forEach(g=>canvas.bringToFront(g));afterChange();}};
  $('back').onclick=()=>{const o=active();if(o){canvas.sendToBack(o);guideObjs.forEach(g=>canvas.sendToBack(g));afterChange();}};
  $('opacity').oninput=()=>{const o=active();$('opacityValue').textContent=$('opacity').value+'%';if(o){o.set('opacity',+$('opacity').value/100);canvas.requestRenderAll();scheduleSave();}};
  $('whiteThreshold').oninput=()=>{$('whiteThresholdValue').textContent=$('whiteThreshold').value;};

  function selectedRaster(){
    const o=active();
    if(!o || o.type!=='image'){
      status('先に加工する画像を選択してください。');
      return null;
    }
    return o;
  }

  function replaceRaster(oldObj,dataUrl,name,keepSize=false){
    const center=oldObj.getCenterPoint();
    const angle=oldObj.angle||0;
    const opacity=oldObj.opacity??1;
    const flipX=!!oldObj.flipX,flipY=!!oldObj.flipY;
    const oldW=oldObj.getScaledWidth(),oldH=oldObj.getScaledHeight();
    const oldIndex=canvas.getObjects().indexOf(oldObj);
    fabric.Image.fromURL(dataUrl,img=>{
      tag(img,name||oldObj._jahName||'画像');
      let sx=oldObj.scaleX,sy=oldObj.scaleY;
      if(keepSize){sx=oldW/img.width;sy=oldH/img.height;}
      img.set({left:center.x,top:center.y,originX:'center',originY:'center',scaleX:sx,scaleY:sy,angle,opacity,flipX,flipY});
      canvas.remove(oldObj);canvas.insertAt(img,Math.max(0,oldIndex),false);canvas.setActiveObject(img);
      afterChange(`${name||'画像加工'}を適用しました。`);
    },{crossOrigin:'anonymous'});
  }

  function processPixels(mode){
    const o=selectedRaster();if(!o)return;
    const el=o.getElement();
    const w=el.naturalWidth||el.width,h=el.naturalHeight||el.height;
    if(!w||!h){status('画像を処理できませんでした。');return;}
    const off=document.createElement('canvas');off.width=w;off.height=h;
    const ctx=off.getContext('2d',{willReadFrequently:true});ctx.drawImage(el,0,0,w,h);
    const im=ctx.getImageData(0,0,w,h),d=im.data;
    if(mode==='white'){
      const t=+$('whiteThreshold').value;
      for(let i=0;i<d.length;i+=4){
        const min=Math.min(d[i],d[i+1],d[i+2]);
        if(min>=t)d[i+3]=0;
      }
      ctx.putImageData(im,0,0);replaceRaster(o,off.toDataURL('image/png'),(o._jahName||'画像')+' 白抜き',true);
    }else{
      for(let i=0;i<d.length;i+=4){if(d[i+3]>0){d[i]=0;d[i+1]=0;d[i+2]=0;}}
      ctx.putImageData(im,0,0);replaceRaster(o,off.toDataURL('image/png'),(o._jahName||'画像')+' 黒ベタ',true);
    }
  }
  $('removeWhite').onclick=()=>processPixels('white');
  $('solidBlack').onclick=()=>processPixels('black');

  function openCrop(){
    const o=selectedRaster();if(!o)return;
    const el=o.getElement(),iw=el.naturalWidth||el.width,ih=el.naturalHeight||el.height;
    const c=$('cropCanvas'),maxW=Math.min(innerWidth-64,520),maxH=Math.min(innerHeight*.52,520);
    const scale=Math.min(maxW/iw,maxH/ih,1);c.width=Math.max(1,Math.round(iw*scale));c.height=Math.max(1,Math.round(ih*scale));
    cropState={obj:o,el,iw,ih,scale,rect:{x:c.width*.06,y:c.height*.06,w:c.width*.88,h:c.height*.88},drag:null};
    drawCrop();$('cropDialog').showModal();
  }
  function drawCrop(){
    if(!cropState)return;const c=$('cropCanvas'),ctx=c.getContext('2d'),r=cropState.rect;
    ctx.clearRect(0,0,c.width,c.height);ctx.drawImage(cropState.el,0,0,c.width,c.height);
    ctx.save();ctx.fillStyle='rgba(0,0,0,.55)';ctx.beginPath();ctx.rect(0,0,c.width,c.height);ctx.rect(r.x,r.y,r.w,r.h);ctx.fill('evenodd');
    ctx.strokeStyle='#fff';ctx.lineWidth=2;ctx.strokeRect(r.x,r.y,r.w,r.h);
    const hs=8;ctx.fillStyle='#fff';[[r.x,r.y],[r.x+r.w,r.y],[r.x,r.y+r.h],[r.x+r.w,r.y+r.h]].forEach(([x,y])=>ctx.fillRect(x-hs/2,y-hs/2,hs,hs));ctx.restore();
  }
  function cropPoint(e){const c=$('cropCanvas'),b=c.getBoundingClientRect();return{x:(e.clientX-b.left)*c.width/b.width,y:(e.clientY-b.top)*c.height/b.height};}
  function cropDown(e){if(!cropState)return;e.preventDefault();const p=cropPoint(e),r=cropState.rect,hit=18;let kind='move';
    const corners=[['tl',r.x,r.y],['tr',r.x+r.w,r.y],['bl',r.x,r.y+r.h],['br',r.x+r.w,r.y+r.h]];
    for(const [k,x,y] of corners)if(Math.hypot(p.x-x,p.y-y)<hit){kind=k;break;}
    if(kind==='move' && !(p.x>=r.x&&p.x<=r.x+r.w&&p.y>=r.y&&p.y<=r.y+r.h))return;
    cropState.drag={kind,start:p,orig:{...r}};$('cropCanvas').setPointerCapture?.(e.pointerId);
  }
  function cropMove(e){if(!cropState?.drag)return;e.preventDefault();const p=cropPoint(e),d=cropState.drag,o=d.orig,dx=p.x-d.start.x,dy=p.y-d.start.y,min=24,c=$('cropCanvas');let r={...o};
    if(d.kind==='move'){r.x=Math.max(0,Math.min(c.width-r.w,o.x+dx));r.y=Math.max(0,Math.min(c.height-r.h,o.y+dy));}
    if(d.kind.includes('l')){const nx=Math.max(0,Math.min(o.x+o.w-min,o.x+dx));r.x=nx;r.w=o.x+o.w-nx;}
    if(d.kind.includes('r'))r.w=Math.max(min,Math.min(c.width-o.x,o.w+dx));
    if(d.kind.includes('t')){const ny=Math.max(0,Math.min(o.y+o.h-min,o.y+dy));r.y=ny;r.h=o.y+o.h-ny;}
    if(d.kind.includes('b'))r.h=Math.max(min,Math.min(c.height-o.y,o.h+dy));
    cropState.rect=r;drawCrop();
  }
  function cropUp(){if(cropState)cropState.drag=null;}
  $('cropCanvas').addEventListener('pointerdown',cropDown);$('cropCanvas').addEventListener('pointermove',cropMove);$('cropCanvas').addEventListener('pointerup',cropUp);$('cropCanvas').addEventListener('pointercancel',cropUp);
  $('cropImage').onclick=openCrop;$('cancelCrop').onclick=()=>{$('cropDialog').close();cropState=null;};
  $('applyCrop').onclick=()=>{if(!cropState)return;const {obj,el,iw,ih,rect,scale}=cropState;
    const sx=Math.max(0,Math.round(rect.x/scale)),sy=Math.max(0,Math.round(rect.y/scale)),sw=Math.max(1,Math.round(rect.w/scale)),sh=Math.max(1,Math.round(rect.h/scale));
    const off=document.createElement('canvas');off.width=Math.min(sw,iw-sx);off.height=Math.min(sh,ih-sy);off.getContext('2d').drawImage(el,sx,sy,off.width,off.height,0,0,off.width,off.height);
    $('cropDialog').close();cropState=null;replaceRaster(obj,off.toDataURL('image/png'),(obj._jahName||'画像')+' トリミング',false);
  };
  $('applyObject').onclick=()=>{const o=active();if(!o)return;const cw=o.getScaledWidth(),ch=o.getScaledHeight(),tw=Math.max(.1,+$('objW').value||cw),th=Math.max(.1,+$('objH').value||ch);if($('lockRatio').value==='on'){const f=tw/cw;o.scaleX*=f;o.scaleY*=f;}else{o.scaleX*=tw/cw;o.scaleY*=th/ch;}o.set({left:+$('objX').value||0,top:+$('objY').value||0,originX:'left',originY:'top',angle:+$('objAngle').value||0});canvas.requestRenderAll();afterChange();};

  function updateInfo(){const o=active();if(!o){$('selectionInfo').textContent='素材を選択してください';['objW','objH','objX','objY','objAngle'].forEach(id=>$(id).value='');$('opacity').value=100;$('opacityValue').textContent='100%';return;}const w=o.getScaledWidth(),h=o.getScaledHeight();$('selectionInfo').textContent=`${o._jahName||o.type}｜横 ${w.toFixed(1)}mm × 縦 ${h.toFixed(1)}mm｜回転 ${Math.round(o.angle||0)}°`; $('objW').value=w.toFixed(1);$('objH').value=h.toFixed(1);$('objX').value=(o.left||0).toFixed(1);$('objY').value=(o.top||0).toFixed(1);$('objAngle').value=Math.round(o.angle||0);$('opacity').value=Math.round((o.opacity??1)*100);$('opacityValue').textContent=$('opacity').value+'%';}
  function refreshLayers(){const host=$('layers');host.innerHTML='';userObjects().slice().reverse().forEach(o=>{const row=document.createElement('div');row.className='layer'+(active()===o?' active':'');const name=document.createElement('button');name.className='name secondary';name.textContent=o._jahName||o.type;name.onclick=()=>{canvas.setActiveObject(o);canvas.requestRenderAll();refreshLayers();updateInfo();};const up=document.createElement('button');up.className='secondary';up.textContent='↑';up.onclick=()=>{canvas.bringForward(o);guideObjs.forEach(g=>canvas.bringToFront(g));afterChange();};const down=document.createElement('button');down.className='secondary';down.textContent='↓';down.onclick=()=>{canvas.sendBackwards(o);guideObjs.forEach(g=>canvas.bringToFront(g));afterChange();};const lock=document.createElement('button');lock.className='secondary';lock.textContent=o.selectable?'🔓':'🔒';lock.onclick=()=>{const v=o.selectable;o.set({selectable:!v,evented:!v});canvas.discardActiveObject();canvas.requestRenderAll();afterChange();};const del=document.createElement('button');del.className='danger';del.textContent='×';del.onclick=()=>{canvas.remove(o);afterChange();};row.append(name,up,down,lock,del);host.appendChild(row);});}
  function snapObject(o){if(!$('snap').checked)return;if(Math.abs(o.getCenterPoint().x-pageW/2)<4)o.set({left:pageW/2,originX:'center'});if(Math.abs(o.getCenterPoint().y-pageH/2)<4)o.set({top:pageH/2,originY:'center'});}

  function snapshot(){return JSON.stringify({version:'1.4',pageW,pageH,template:$('template').value,guides:$('guides').checked,grid:$('grid').checked,snap:$('snap').checked,json:canvas.toJSON(['_jahId','_jahName','excludeFromExport'])});}
  function recordHistory(){if(historyBusy)return;const s=snapshot();if(history[historyIndex]===s)return;history=history.slice(0,historyIndex+1);history.push(s);if(history.length>30)history.shift();historyIndex=history.length-1;updateHistoryButtons();}
  function updateHistoryButtons(){$('undo').disabled=historyIndex<=0;$('redo').disabled=historyIndex>=history.length-1;}
  function loadState(state){historyBusy=true;const d=JSON.parse(state);pageW=d.pageW;pageH=d.pageH;$('template').value=d.template||'custom';$('docW').value=pageW;$('docH').value=pageH;$('guides').checked=d.guides!==false;$('grid').checked=!!d.grid;$('snap').checked=d.snap!==false;canvas.loadFromJSON(d.json,()=>{resizeCanvas();refreshLayers();updateInfo();historyBusy=false;scheduleSave();updateHistoryButtons();});}
  $('undo').onclick=()=>{if(historyIndex>0){historyIndex--;loadState(history[historyIndex]);}};
  $('redo').onclick=()=>{if(historyIndex<history.length-1){historyIndex++;loadState(history[historyIndex]);}};

  canvas.on('object:moving',e=>snapObject(e.target));
  canvas.on('object:modified',()=>afterChange());
  canvas.on('selection:created',()=>{refreshLayers();updateInfo();});canvas.on('selection:updated',()=>{refreshLayers();updateInfo();});canvas.on('selection:cleared',()=>{refreshLayers();updateInfo();});canvas.on('object:added',refreshLayers);canvas.on('object:removed',refreshLayers);

  function saveNow(){try{localStorage.setItem(KEY,snapshot());status('自動保存しました。');}catch(e){status('保存容量が不足しています。');}}
  function scheduleSave(){clearTimeout(saveTimer);saveTimer=setTimeout(saveNow,350);}
  $('saveProject').onclick=saveNow;$('clearProject').onclick=()=>{localStorage.removeItem(KEY);status('保存データを消去しました。');};
  function restore(){const raw=localStorage.getItem(KEY);if(!raw){applyTemplate('a3p',false);history=[snapshot()];historyIndex=0;updateHistoryButtons();return;}try{historyBusy=true;const d=JSON.parse(raw);pageW=d.pageW||297;pageH=d.pageH||420;$('template').value=d.template||'custom';$('docW').value=pageW;$('docH').value=pageH;$('guides').checked=d.guides!==false;$('grid').checked=!!d.grid;$('snap').checked=d.snap!==false;canvas.loadFromJSON(d.json,()=>{resizeCanvas();refreshLayers();updateInfo();historyBusy=false;history=[snapshot()];historyIndex=0;updateHistoryButtons();status('前回のプロジェクトを復元しました。');});}catch(e){historyBusy=false;applyTemplate('a3p',false);history=[snapshot()];historyIndex=0;updateHistoryButtons();}}

  function withoutGuides(fn){const old=guideObjs.map(g=>g.visible);guideObjs.forEach(g=>g.visible=false);canvas.discardActiveObject();canvas.requestRenderAll();try{return fn();}finally{guideObjs.forEach((g,i)=>g.visible=old[i]);canvas.requestRenderAll();}}
  function download(url,name){const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();}
  $('exportPng').onclick=()=>{download(withoutGuides(()=>canvas.toDataURL({format:'png',multiplier:4,enableRetinaScaling:true})),'JAH_STUDIO_design.png');status('PNGを書き出しました。');};
  $('exportSvg').onclick=()=>{const svg=withoutGuides(()=>canvas.toSVG({width:pageW+'mm',height:pageH+'mm',viewBox:{x:0,y:0,width:pageW,height:pageH}})),b=new Blob([svg],{type:'image/svg+xml'}),u=URL.createObjectURL(b);download(u,'JAH_STUDIO_design.svg');setTimeout(()=>URL.revokeObjectURL(u),1000);status('SVGを書き出しました。');};
  $('exportPdf').onclick=()=>{const img=withoutGuides(()=>canvas.toDataURL({format:'png',multiplier:4,enableRetinaScaling:true})),pdf=new jsPDF({orientation:pageW>pageH?'landscape':'portrait',unit:'mm',format:[pageW,pageH]});pdf.addImage(img,'PNG',0,0,pageW,pageH,undefined,'FAST');pdf.save('JAH_STUDIO_print.pdf');status('PDFを書き出しました。');};

  addEventListener('resize',resizeCanvas);restore();
})();
